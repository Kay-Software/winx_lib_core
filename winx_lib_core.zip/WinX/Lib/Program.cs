using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace Microsoft.PowerShell
{
    public sealed class ManagedPSEntry
    {
#if UNIX
        private class StartupException : Exception
        {
            public StartupException(string callName, int exitCode)
            {
                CallName = callName;
                ExitCode = exitCode;
            }
            public string CallName { get; }
            public int ExitCode { get; }
        }

        // Environment variable used to short circuit second login check
        private const string LOGIN_ENV_VAR_NAME = "__PWSH_LOGIN_CHECKED";
        private const string LOGIN_ENV_VAR_VALUE = "1";

        // Linux p/Invoke constants
        private const int LINUX_PATH_MAX = 4096;

        // MacOS p/Invoke constants
        private const int MACOS_CTL_KERN = 1;
        private const int MACOS_KERN_ARGMAX = 8;
        private const int MACOS_KERN_PROCARGS2 = 49;
        private const int MACOS_PROC_PIDPATHINFO_MAXSIZE = 4096;
#endif
        public static int Main(string[] args)
        {
#if UNIX
            AttemptExecPwshLogin(args);
#endif
            return UnmanagedPSEntry.Start(string.Empty, args, args.Length);
        }

#if UNIX
        private static void AttemptExecPwshLogin(string[] args)
        {
            if (Environment.GetEnvironmentVariable(LOGIN_ENV_VAR_NAME) != null)
            {
                Environment.SetEnvironmentVariable(LOGIN_ENV_VAR_NAME, null);
                return;
            }
            bool isLinux = RuntimeInformation.IsOSPlatform(OSPlatform.Linux);
            byte procNameFirstByte;
            string pwshPath;
            if (isLinux)
            {
                using (FileStream fs = File.OpenRead("/proc/self/cmdline"))
                {
                    procNameFirstByte = (byte)fs.ReadByte();
                }
                if (!IsLogin(procNameFirstByte, args))
                {
                    return;
                }
                IntPtr linkPathPtr = Marshal.AllocHGlobal(LINUX_PATH_MAX);
                IntPtr bufSize = ReadLink("/proc/self/exe", linkPathPtr, (UIntPtr)LINUX_PATH_MAX);
                pwshPath = Marshal.PtrToStringAnsi(linkPathPtr, (int)bufSize);
                Marshal.FreeHGlobal(linkPathPtr);
                ThrowOnFailure("exec", ExecPwshLogin(args, pwshPath, isMacOS: false));
                return;
            }
            Span<int> mib = stackalloc int[3];
            int mibLength = 2;
            mib[0] = MACOS_CTL_KERN;
            mib[1] = MACOS_KERN_ARGMAX;
            int size = IntPtr.Size / 2;
            int argmax = 0;

            // Get the process args size
            unsafe
            {
                fixed (int *mibptr = mib)
                {
                    ThrowOnFailure(nameof(argmax), SysCtl(mibptr, mibLength, &argmax, &size, IntPtr.Zero, 0));
                }
            }
            int pid = GetPid();
            IntPtr procargs = Marshal.AllocHGlobal(argmax);
            IntPtr executablePathPtr = IntPtr.Zero;
            try
            {
                mib[0] = MACOS_CTL_KERN;
                mib[1] = MACOS_KERN_PROCARGS2;
                mib[2] = pid;
                mibLength = 3;

                unsafe
                {
                    fixed (int *mibptr = mib)
                    {
                        ThrowOnFailure(nameof(procargs), SysCtl(mibptr, mibLength, procargs.ToPointer(), &argmax, IntPtr.Zero, 0));
                    }
                    procNameFirstByte = *argvPtr;
                }

                if (!IsLogin(procNameFirstByte, args))
                {
                    return;
                }
                pwshPath = Marshal.PtrToStringAnsi(executablePathPtr);
                ThrowOnFailure("exec", ExecPwshLogin(args, pwshPath, isMacOS: true));
            }
            finally
            {
                Marshal.FreeHGlobal(procargs);
            }
        }
        private static bool IsLogin(
            byte procNameFirstByte,
            string[] args)
        {
            // Process name starting with '-' means this is a login shell
            if (procNameFirstByte == 0x2D)
            {
                return true;
            }
            return args.Length > 0
                && args[0].Length > 1
                && args[0][0] == '-'
                && IsParam(args[0], "login", "LOGIN");
        }
        private static bool IsParam(
            string arg,
            string paramToCheck,
            string paramToCheckUpper)
        {
            // Quick fail if the argument is longer than the parameter
            if (arg.Length > paramToCheck.Length + 1)
            {
                return false;
            }

            // Check arg chars in order and allow prefixes
            for (int i = 1; i < arg.Length; i++)
            {
                if (arg[i] != paramToCheck[i-1]
                    && arg[i] != paramToCheckUpper[i-1])
                {
                    return false;
                }
            }

            return true;
        }
        private static int ExecPwshLogin(string[] args, string pwshPath, bool isMacOS)
        {
            int quotedPwshPathLength = GetQuotedPathLength(pwshPath);

            string pwshInvocation = string.Create(
                quotedPwshPathLength + 10, // exec '{pwshPath}' "$@" 
                (pwshPath, quotedPwshPathLength),
                CreatePwshInvocation);
            var execArgs = new string[args.Length + 6];
            execArgs[0] = "/bin/sh"; 
            execArgs[1] = "-l"; // Login flag
            execArgs[2] = "-c"; // Command parameter
            execArgs[3] = pwshInvocation; // Command to execute
            execArgs[4] = "";

            // Add the arguments passed to pwsh on the end.
            args.CopyTo(execArgs, 5);

            // A null is required by exec.
            execArgs[execArgs.Length - 1] = null;
            ThrowOnFailure("setenv", SetEnv(LOGIN_ENV_VAR_NAME, LOGIN_ENV_VAR_VALUE, overwrite: true));
            if (isMacOS)
            {
                return Exec("/bin/zsh", execArgs);
            }

            return Exec("/bin/sh", execArgs);
        }
        private static int GetQuotedPathLength(string str)
        {
            int length = 2;
            foreach (char c in str)
            {
                length++;
                if (c == '\'') { length++; }
            }

            return length;
        }
        private static void CreatePwshInvocation(
            Span<char> strBuf,
            (string path, int quotedLength) invocationInfo)
        {
            string prefix = "exec ";
            prefix.AsSpan().CopyTo(strBuf);
            int i = prefix.Length;
            Span<char> pathSpan = strBuf.Slice(i, invocationInfo.quotedLength);
            QuoteAndWriteToSpan(invocationInfo.path, pathSpan);
            i += invocationInfo.quotedLength;
            string suffix = " \"$@\"";
            Span<char> bufSuffix = strBuf.Slice(i);
            suffix.AsSpan().CopyTo(bufSuffix);
        }
        private static void QuoteAndWriteToSpan(string arg, Span<char> span)
        {
            span[0] = '\'';

            int i = 0;
            int j = 1;
            for (; i < arg.Length; i++, j++)
            {
                char c = arg[i];

                if (c == '\'')
                {
                    // /bin/sh quote escaping uses backslashes
                    span[j] = '\\';
                    j++;
                }

                span[j] = c;
            }

            span[j] = '\'';
        }
        private static void ThrowOnFailure(string call, int code)
        {
            if (code < 0)
            {
                code = Marshal.GetLastWin32Error();
                Console.Error.WriteLine($"Call to '{call}' failed with errno {code}");
                throw new StartupException(call, code);
            }
        }
        [DllImport("libc",
            EntryPoint = "execv",
            CallingConvention = CallingConvention.Cdecl,
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static extern int Exec(string path, string[] args);
        [DllImport("libc",
            EntryPoint = "readlink",
            CallingConvention = CallingConvention.Cdecl,
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static extern IntPtr ReadLink(string pathname, IntPtr buf, UIntPtr size);
        [DllImport("libc",
            EntryPoint = "getpid",
            CallingConvention = CallingConvention.Cdecl,
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static extern int GetPid();
        [DllImport("libc",
            EntryPoint = "setenv",
            CallingConvention = CallingConvention.Cdecl,
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static extern int SetEnv(string name, string value, bool overwrite);
        [DllImport("libc",
            EntryPoint = "sysctl",
            CallingConvention = CallingConvention.Cdecl,
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static unsafe extern int SysCtl(int *mib, int mibLength, void *oldp, int *oldlenp, IntPtr newp, int newlenp);
#endif
    }
}
