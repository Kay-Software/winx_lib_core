// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
using System.ServiceProcess;

namespace TestService
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
        }

        protected override void OnStop()
        {
        }
    }
}
